//
// Created by Abrar on 16/7/24
// Copyright © 2024 Abrar. All rights reserved.
//

import Combine
import SwiftUI
import UIKit

class ViewController: UIViewController {
    private let viewModel = ViewModel()
    private var cancellables = Set<AnyCancellable>()

    private lazy var leftBarButton: UIBarButtonItem = {
        .init(title: "Cancel", style: .plain, target: self, action: #selector(cancelClicked))
    }()

    private lazy var rightBarButton: UIBarButtonItem = {
        .init(title: "Next", style: .plain, target: self, action: #selector(nextClicked))
    }()

    override func viewDidLoad() {
        super.viewDidLoad()

        viewModel.enableNextButtonPublisher
            .receive(on: DispatchQueue.main)
            .sink { [weak self] in self?.rightBarButton.isEnabled = $0 }
            .store(in: &cancellables)

        setupView()
        setupNavigation()
    }
}

private extension ViewController {
    func setupView() {
        guard let hostingView = UIHostingController(
            rootView: SwiftUIView(viewModel: viewModel).navigationBarHidden(true)
        ).view
        else { return }

        hostingView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(hostingView)

        NSLayoutConstraint.activate([
            hostingView.topAnchor.constraint(equalTo: view.topAnchor),
            hostingView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            hostingView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            hostingView.trailingAnchor.constraint(equalTo: view.trailingAnchor)
        ])
    }

    func setupNavigation() {
        navigationItem.title = "This is a view"
        navigationItem.leftBarButtonItem = leftBarButton
        navigationItem.rightBarButtonItem = rightBarButton
    }

    @objc
    func cancelClicked() {
        print("Cancel clicked")
    }

    @objc
    func nextClicked() {
        print("Next clicked")
    }
}
