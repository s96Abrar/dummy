//
// Created by Abrar on 16/7/24
// Copyright © 2024 Abrar. All rights reserved.
//

import Combine
import Foundation

struct ListItem: Identifiable {
    let id = UUID()
    let name: String
    let type: String
    var subTitle: String?
    var isChecked: Bool
}

final class ViewModel: ObservableObject {
    @Published var items: [ListItem] = []

    private var cancellable: AnyCancellable?
    private var timerValue = 0

    init(items: [ListItem] = dummyItems) {
        self.items = items
        initiateTimerObserver()
    }

    private func initiateTimerObserver() {
        cancellable = Timer.publish(every: 1, on: .main, in: .common)
            .autoconnect()
            .sink { [weak self] _ in
                guard
                    let self,
                    !items.isEmpty
                else { return }

                let index = Int.random(in: 0..<items.count)
                let number = Int.random(in: 100...1000)

                timerValue += 1

                items[index].subTitle = "\(number)"
                if timerValue % 7 == 0 {
                    items.removeLast()
                }
            }
    }
}

extension ViewModel {
    var sections: [String] {
        Set<String>(items.map { $0.type }).sorted()
    }

    var sectionWiseIndices: [String: [Int]] {
        var index = 0
        var indicesMap = [String: [Int]]()

        items.forEach { item in
            if let indices = indicesMap[item.type] {
                if !indices.contains(where: { $0 == index }) {
                    indicesMap[item.type]?.append(index)
                }
            } else {
                indicesMap[item.type] = [index]
            }
            index += 1
        }
        return indicesMap
    }

    var enableNextButtonPublisher: AnyPublisher<Bool, Never> {
        $items.map { $0.contains(where: { $0.isChecked }) }
            .prepend(false)
            .eraseToAnyPublisher()
    }
}

private extension ViewModel {
    static let dummyItems: [ListItem] = [
        .init(name: "1", type: "ABC", isChecked: false),
        .init(name: "2", type: "JKL", isChecked: false),
        .init(name: "3", type: "ABC", isChecked: false),
        .init(name: "4", type: "XYZ", isChecked: false),
        .init(name: "5", type: "PQR", isChecked: false),
    ]
}
