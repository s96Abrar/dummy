//
// Created by Abrar on 16/7/24
// Copyright © 2024 Abrar. All rights reserved.
//

import SwiftUI

struct ListItemView: View {
    @Binding var item: ListItem
    var body: some View {
        HStack {
            Image(systemName: item.isChecked ? "checkmark.square.fill" : "square")
                .onTapGesture {
                    item.isChecked.toggle()
                }

            Spacer(minLength: 15)

            VStack(alignment: .leading, spacing: 10) {
                Text("\(item.name)")
                    .frame(maxWidth: .infinity, alignment: .leading)

                if let subTitle = item.subTitle {
                    Text("\(subTitle)")
                        .font(.system(size: 14))
                        .foregroundStyle(.secondary)
                        .frame(maxWidth: .infinity, alignment: .leading)
                }
            }
        }
    }
}

struct SwiftUIView: View {
    @ObservedObject var viewModel: ViewModel

    var body: some View {
        List {
            ForEach(viewModel.sections, id: \.self) { section in
                Section(section) {
                    if let indices = viewModel.sectionWiseIndices[section] {
                        ForEach(indices, id: \.self) { index in
                            ListItemView(item: $viewModel.items[index])
                        }
                    }
                }
            }
        }
    }
}

#Preview {
    SwiftUIView(viewModel: ViewModel())
}
